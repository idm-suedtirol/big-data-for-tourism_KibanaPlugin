export default function(kibana) {
  return new kibana.Plugin({
    id: "dashboard_edit_filters",
    require: ['kibana', 'elasticsearch'],
    uiExports: {
      hacks: [
        'plugins/dashboard_edit_filters/main'
      ]
    }
  });
};
