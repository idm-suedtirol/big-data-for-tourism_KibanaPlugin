import 'plugins/dashboard_edit_filters/less/main.less';
