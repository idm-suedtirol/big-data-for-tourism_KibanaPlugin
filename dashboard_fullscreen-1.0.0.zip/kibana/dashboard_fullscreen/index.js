
export default function(kibana) {
  return new kibana.Plugin({
    id: "dashboard_fullscreen",
    require: ['kibana', 'elasticsearch'],
    uiExports: {
      hacks: [
        'plugins/dashboard_fullscreen/main'
      ]
    }
  });
};
