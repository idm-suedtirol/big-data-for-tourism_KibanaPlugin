import 'plugins/dashboard_fullscreen/less/main.less';
