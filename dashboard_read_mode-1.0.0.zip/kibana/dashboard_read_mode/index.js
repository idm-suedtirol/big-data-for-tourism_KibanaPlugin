import { resolve } from "path";

import { createDashboardModeRequestInterceptor } from "./server";

export default function(kibana) {
//export function dashboardReadViewer(kibana) {
  const kbnBaseUrl = "/app/kibana";
  return new kibana.Plugin({
    id: "dashboard_read_mode",
    require: ["kibana", "elasticsearch"],
    uiExports: {
      app: {
        id: "dashboardReadViewer",
        title: "Kibana Read Only",
        listed: false,
        hidden: true,
        description: "An awesome Kibana plugin",
        main: "plugins/dashboard_read_mode/dashboard_read_viewer",
        links: [
          {
            id: "kibana:dashboard",
            title: "Dashboard",
            order: -1001,
            url: `${kbnBaseUrl}#/dashboards`,
            subUrlBase: `${kbnBaseUrl}#/dashboard`,
            description: "Dashboard Viewer",
            icon: "plugins/kibana/assets/dashboard.svg"
          }
        ]
      }
    },

    config(Joi) {
      return Joi.object({
        enabled: Joi.boolean().default(true)
      }).default();
    },

    init(server) {
      server.injectUiAppVars('dashboardReadViewer', async () => (
        await server.getInjectedUiAppVars('kibana')
      ));

      // Add server routes and initalize the plugin here
      const dashboardReadViewerApp = server.getHiddenUiAppById("dashboardReadViewer");
      server.ext(createDashboardModeRequestInterceptor(dashboardReadViewerApp));
    }
  });
}
