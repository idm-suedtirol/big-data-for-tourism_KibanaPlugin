import chrome from 'ui/chrome';
import routes from 'ui/routes';
import { uiModules } from 'ui/modules';

// import the uiExports that we want to "use"
import 'uiExports/visTypes';
import 'uiExports/visResponseHandlers';
import 'uiExports/visRequestHandlers';
import 'uiExports/visEditorTypes';
import 'uiExports/inspectorViews';
import 'uiExports/savedObjectTypes';
import 'uiExports/embeddableFactories';
import 'uiExports/navbarExtensions';
import 'uiExports/docViews';
import 'uiExports/fieldFormats';
import 'uiExports/search';
import 'uiExports/autocompleteProviders';
import 'ui/autoload/all';
import 'plugins/kibana/dashboard';
import 'ui/vislib';
import 'ui/agg_response';
import 'ui/agg_types';
import 'ui/timepicker';
import 'leaflet';

import { Notifier } from 'ui/notify';
import { DashboardConstants } from 'plugins/kibana/dashboard/dashboard_constants';
import { KibanaRootController } from 'plugins/kibana/kibana_root_controller';

uiModules.get('kibana')
  .config(dashboardConfigProvider => dashboardConfigProvider.turnHideWriteControlsOn());

routes.enable();
routes.otherwise({ redirectTo: DashboardConstants.LANDING_PAGE_PATH });

chrome
  .setRootController('kibana', function ($controller, $scope, courier, config) {
    chrome.showOnlyById('kibana:dashboard');
    $controller(KibanaRootController, { $scope, courier, config });
  });

uiModules.get('kibana').run(Notifier.pullMessageFromUrl);
