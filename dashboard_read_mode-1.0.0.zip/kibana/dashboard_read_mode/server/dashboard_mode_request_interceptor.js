import Boom from 'boom';

/**
 *  Intercept all requests after auth has completed
 *
 *  @type {Hapi.RequestExtension}
 */
export function createDashboardModeRequestInterceptor(dashboardReadViewerApp) {
  if (!dashboardReadViewerApp) {
    throw new TypeError('Expected to receive a `dashboardReadViewerApp` argument');
  }

  return {
    type: 'onPostAuth',
    method(request, reply) {
      const { auth, url } = request;
      const isAppRequest = url.path.startsWith('/app/');

      if (isAppRequest) {
        if (url.path.startsWith('/app/kibana')) {
          reply.renderApp(dashboardReadViewerApp);
          return;
        }

        reply(Boom.notFound());
        return;
      }

      reply.continue();
    }
  };
}
