export default function (kibana) {
  return new kibana.Plugin({
    uiExports: {
      visTypes: [
        'plugins/date_picker_vis/register_vis'
      ]
    }
  });
}
