import './control_editor.less';
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { RangeControlEditor } from './range_control_editor';
import { getTitle } from '../../editor_utils';

import {
  EuiAccordion,
  EuiButtonIcon,
  EuiFieldText,
  EuiForm,
  EuiFormRow,
  EuiPanel,
  EuiSpacer,
} from '@elastic/eui';

export class ControlEditor extends Component {
  changeLabel = evt => {
    this.props.handleLabelChange(this.props.controlIndex, evt);
  };

  changeIndexPattern = evt => {
    this.props.handleIndexPatternChange(this.props.controlIndex, evt);
  };

  changeFieldName = evt => {
    this.props.handleFieldNameChange(this.props.controlIndex, evt);
  };

  renderEditor() {
    let controlEditor = (
      <RangeControlEditor
        controlIndex={this.props.controlIndex}
        controlParams={this.props.controlParams}
        handleIndexPatternChange={this.changeIndexPattern}
        handleFieldNameChange={this.changeFieldName}
        getIndexPatterns={this.props.getIndexPatterns}
        getIndexPattern={this.props.getIndexPattern}
      />
    );

    const labelId = `controlLabel${this.props.controlIndex}`;
    return (
      <EuiForm>
        <EuiFormRow id={labelId} label="Control Label">
          <EuiFieldText value={this.props.controlParams.label} onChange={this.changeLabel} />
        </EuiFormRow>

        {controlEditor}
      </EuiForm>
    );
  }

  render() {
    return (
      <EuiPanel grow={false} className="controlEditorPanel">
        {this.renderEditor()}
      </EuiPanel>
    );
  }
}

ControlEditor.propTypes = {
  controlIndex: PropTypes.number.isRequired,
  controlParams: PropTypes.object.isRequired,
  handleLabelChange: PropTypes.func.isRequired,
  moveControl: PropTypes.func.isRequired,
  handleRemoveControl: PropTypes.func.isRequired,
  handleIndexPatternChange: PropTypes.func.isRequired,
  handleFieldNameChange: PropTypes.func.isRequired,
  getIndexPatterns: PropTypes.func.isRequired,
  getIndexPattern: PropTypes.func.isRequired,
  handleCheckboxOptionChange: PropTypes.func.isRequired,
  parentCandidates: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      text: PropTypes.string.isRequired,
    })
  ).isRequired,
  handleParentChange: PropTypes.func.isRequired,
};
