import _ from 'lodash';
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { ControlEditor } from './control_editor';
import { addControl, moveControl, newControl, removeControl, setControl } from '../../editor_utils';
import { getLineageMap, getParentCandidates } from '../../lineage';

import {
  EuiButton,
  EuiFlexGroup,
  EuiFlexItem,
  EuiFormRow,
  EuiPanel,
  EuiSelect,
} from '@elastic/eui';

export class ControlsTab extends Component {
  state = {};

  getIndexPatterns = async search => {
    const resp = await this.props.scope.vis.API.savedObjectsClient.find({
      type: 'index-pattern',
      fields: ['title'],
      search: `${search}*`,
      search_fields: ['title'],
      perPage: 100,
    });
    return resp.savedObjects;
  };

  getIndexPattern = async indexPatternId => {
    return await this.props.scope.vis.API.indexPatterns.get(indexPatternId);
  };

  setVisParam(paramName, paramValue) {
    const params = _.cloneDeep(this.props.editorState.params);
    params[paramName] = paramValue;
    this.props.stageEditorParams(params);
  }

  handleLabelChange = (controlIndex, evt) => {
    const updatedControl = this.props.editorState.params.controls[controlIndex];
    updatedControl.label = evt.target.value;
    this.setVisParam(
      'controls',
      setControl(this.props.editorState.params.controls, controlIndex, updatedControl)
    );
  };

  handleIndexPatternChange = (controlIndex, indexPatternId) => {
    const updatedControl = this.props.editorState.params.controls[controlIndex];
    updatedControl.indexPattern = indexPatternId;
    updatedControl.fieldName = '';
    this.setVisParam(
      'controls',
      setControl(this.props.editorState.params.controls, controlIndex, updatedControl)
    );
  };

  handleFieldNameChange = (controlIndex, fieldName) => {
    const updatedControl = this.props.editorState.params.controls[controlIndex];
    updatedControl.fieldName = fieldName;
    this.setVisParam(
      'controls',
      setControl(this.props.editorState.params.controls, controlIndex, updatedControl)
    );
  };

  handleCheckboxOptionChange = (controlIndex, optionName, evt) => {
    const updatedControl = this.props.editorState.params.controls[controlIndex];
    updatedControl.options[optionName] = evt.target.checked;
    this.setVisParam(
      'controls',
      setControl(this.props.editorState.params.controls, controlIndex, updatedControl)
    );
  };

  handleRemoveControl = controlIndex => {
    this.setVisParam(
      'controls',
      removeControl(this.props.editorState.params.controls, controlIndex)
    );
  };

  moveControl = (controlIndex, direction) => {
    this.setVisParam(
      'controls',
      moveControl(this.props.editorState.params.controls, controlIndex, direction)
    );
  };

  handleParentChange = (controlIndex, evt) => {
    const updatedControl = this.props.editorState.params.controls[controlIndex];
    updatedControl.parent = evt.target.value;
    this.setVisParam(
      'controls',
      setControl(this.props.editorState.params.controls, controlIndex, updatedControl)
    );
  };

  renderControls() {
    const lineageMap = getLineageMap(this.props.editorState.params.controls);
    return this.props.editorState.params.controls.map((controlParams, controlIndex) => {
      const parentCandidates = getParentCandidates(
        this.props.editorState.params.controls,
        controlParams.id,
        lineageMap
      );
      return (
        <ControlEditor
          key={controlParams.id}
          controlIndex={controlIndex}
          controlParams={controlParams}
          handleLabelChange={this.handleLabelChange}
          moveControl={this.moveControl}
          handleRemoveControl={this.handleRemoveControl}
          handleIndexPatternChange={this.handleIndexPatternChange}
          handleFieldNameChange={this.handleFieldNameChange}
          getIndexPatterns={this.getIndexPatterns}
          getIndexPattern={this.getIndexPattern}
          handleCheckboxOptionChange={this.handleCheckboxOptionChange}
          parentCandidates={parentCandidates}
          handleParentChange={this.handleParentChange}
        />
      );
    });
  }

  render() {
    return (
      <div>
        {this.renderControls()}
      </div>
    );
  }
}

ControlsTab.propTypes = {
  scope: PropTypes.object.isRequired,
  stageEditorParams: PropTypes.func.isRequired,
};
