import _ from 'lodash';
import PropTypes from 'prop-types';
import React, { Component } from 'react';

import {
  EuiForm,
  EuiFormRow,
  EuiSwitch,
  EuiFieldText,
} from '@elastic/eui';

export class OptionsTab extends Component {

  setVisParam = (paramName, paramValue) => {
    const params = _.cloneDeep(this.props.editorState.params);
    params[paramName] = paramValue;
    this.props.stageEditorParams(params);
  }

  handleShowTimeSelect = (evt) => {
    this.setVisParam('showTimeSelect', evt.target.checked);
  }

  handleDateFormatChange = (evt) => {
    this.setVisParam('dateFormat', evt.target.value);
  };

  render() {
    return (
      <EuiForm>
        <EuiFormRow
          id="showTimeSelect"
        >
          <EuiSwitch
            label="Show Time Select"
            checked={this.props.editorState.params.showTimeSelect}
            onChange={this.handleShowTimeSelect}
            data-test-subj="inputControlEditorhandleShowTimeSelectCheckbox"
          />
        </EuiFormRow>

        <EuiFormRow
          id="dateFormat"
        >
        <EuiFieldText
          placeholder="DD/MM/YYYY"
          value={this.props.editorState.params.dateFormat}
          onChange={this.handleDateFormatChange}
          aria-label="Use aria labels when no actual label is in use"
        />
        </EuiFormRow>

      </EuiForm>
    );
  }
}

OptionsTab.propTypes = {
  scope: PropTypes.object.isRequired,
  stageEditorParams: PropTypes.func.isRequired
};
