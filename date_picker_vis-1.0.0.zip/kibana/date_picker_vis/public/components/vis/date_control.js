import PropTypes from 'prop-types';
import React, { Component } from 'react';
import _ from 'lodash';
import { FormRow } from './form_row';

import moment from 'moment';

import {
  EuiFieldText,
  EuiDatePicker,
  EuiPopover,

  EuiText,
  EuiCard,
  EuiIcon,
  EuiPanel,
} from '@elastic/eui';

export class DateControl extends Component {

  state = {
    isLoading: false,
    //startDate: null,
    //endDate: null,

    isPopoverStartOpen: false,
    isPopoverEndOpen: false,
  }


  componentDidMount = () => {
    this._isMounted = true;
  }

  componentWillUnmount = () => {
    this._isMounted = false;
  }

  handleChangeStart = (date) => {
    this.setState({
      startDate: date,
      isPopoverStartOpen: false,
      isPopoverEndOpen: !this.props.endDate
    });

    this.props.stageFilter(
      this.props.controlIndex,
      this.prepareStageFilter(date, moment(this.props.endDate))
    );
    /*
    if(this.props.endDate){
      this.props.stageFilter(
        this.props.controlIndex,
        this.prepareStageFilter(date, this.props.endDate)
      );
    }*/
  }

  prepareStageFilter = (startDate, endDate) => {
    const sd = startDate ? startDate.set({hour:0,minute:0,second:0,millisecond:0}).valueOf() : null;
    const ed = endDate ? endDate.set({hour:23,minute:59,second:59,millisecond:999}).valueOf() : null;
    return{
      startDate: sd,
      endDate: ed,
    };
  }

  handleChangeEnd = (date) => {
    this.setState({
      endDate: date,
      isPopoverEndOpen: false,
      isPopoverStartOpen: !this.props.startDate
    });
    this.props.stageFilter(
      this.props.controlIndex,
      this.prepareStageFilter(moment(this.props.startDate), date)
    );
    /*
    if(this.props.startDate){
      this.props.stageFilter(
        this.props.controlIndex,
        this.prepareStageFilter(this.props.startDate, date)
      );
    }*/
  }

  onButtonClearClick = () => {
    this.setState({
      startDate: null,
      endDate: null,
    });
    //this.props.resetControls();
    this.props.stageFilter(this.props.controlIndex, []);
  }

  onButtonStartClick = () => {
    this.setState({
      isPopoverStartOpen: !this.state.isPopoverStartOpen,
      isPopoverEndOpen: false,
    });
  }

  onButtonEndClick = () => {
    this.setState({
      isPopoverEndOpen: !this.state.isPopoverEndOpen,
      isPopoverStartOpen: false,
    });
  }

  closePopover = () => {
    this.setState({
      isPopoverEndOpen: false,
      isPopoverStartOpen: false,
    });
  }

  setPanelRef = node => this.panel = node;

  renderControl() {
      const startValueDate = this.props.startDate && moment(this.props.startDate).format(this.props.dateFormat) || "";
      const endValueDate = this.props.endDate && moment(this.props.endDate).format(this.props.dateFormat) || "";
      const button = (
       <EuiPanel paddingSize="none" className="euiDatePickerRange">
          <EuiText
            size="s"
            className="euiDatePickerRange__icon"
          >
          <EuiIcon
            size="m"
            type='calendar'
          />
          </EuiText>
          {((this.props.startDate || this.props.endDate) && !this.state.isPopoverStartOpen && !this.state.isPopoverEndOpen) ? (
            <EuiText
              size="s"
              className="euiDatePickerRange__icon"
              onClick={this.onButtonClearClick}
            >
            <EuiIcon
              className="button_control_hover"
              color='#A30000'
              size="m"
              type='cross'
            />
            </EuiText>
          ) : null
        }
          <EuiFieldText
            className="euiDatePicker"
            placeholder="From"
            value={startValueDate}
            onClick={this.onButtonStartClick}
            onChange={this.handleChangeStart}
            aria-label="Use aria labels when no actual label is in use"
          />
          <EuiText
            size="s"
          >
          →
          </EuiText>
          <EuiFieldText
            className="euiDatePicker"
            placeholder="To"
            value={endValueDate}
            onClick={this.onButtonEndClick}
            onChange={this.handleChangeEnd}
            aria-label="Use aria labels when no actual label is in use"
          />
       </EuiPanel>
      );

      return (
        <EuiPopover
          id="popover"
          button={button}
          isOpen={this.state.isPopoverStartOpen || this.state.isPopoverEndOpen}
          closePopover={this.closePopover}
          container={this.panel}
        >
        {this.state.isPopoverStartOpen && !this.state.isPopoverEndOpen ?
          (
          <EuiDatePicker
            selected={this.props.startDate ? moment(this.props.startDate) : null}
            onChange={this.handleChangeStart}
            inline
            isInvalid={this.props.startDate > this.props.endDate}
            aria-label="Start date"
            showTimeSelect={this.props.showTimeSelect}
            shadow={false}
            dateFormat={this.props.dateFormat}
          />)
          : null }
          {this.state.isPopoverEndOpen && !this.state.isPopoverStartOpen ?
            (
          <EuiDatePicker
            selected={this.props.endDate ? moment(this.props.endDate) : null}
            onChange={this.handleChangeEnd}
            startDate={this.props.startDate}
            inline
            isInvalid={this.props.startDate > this.props.endDate}
            aria-label="End date"
            showTimeSelect={this.props.showTimeSelect}
            shadow={false}
            dateFormat={this.props.dateFormat}
          />)
          : null }

        </EuiPopover>
      );
    }


  render() {
    return (
      <FormRow
        id={this.props.id}
        label=""
        controlIndex={this.props.controlIndex}
        disableMsg={this.props.disableMsg}

        panelRef={this.setPanelRef}
      >
        {this.renderControl()}
      </FormRow>
    );
  }


}

DateControl.propTypes = {
  id: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  //startDate: PropTypes.Day,
  //endDate: PropTypes.Day,
  stageFilter: PropTypes.func.isRequired,
  clearControls: PropTypes.func.isRequired,
  showTimeSelect: PropTypes.bool.isRequired,
  dateFormat: PropTypes.string.isRequired,
};
