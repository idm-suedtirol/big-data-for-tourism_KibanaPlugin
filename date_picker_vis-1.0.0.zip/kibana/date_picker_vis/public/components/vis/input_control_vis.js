import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { DateControl } from './date_control';
import {
  EuiButton,
  EuiFlexGroup,
  EuiFlexItem,
  EuiFormRow
} from '@elastic/eui';

import moment from 'moment';

export class InputControlVis extends Component {
  constructor(props) {
    super(props);

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleReset = this.handleReset.bind(this);
    this.handleClear = this.handleClear.bind(this);
  }

  handleSubmit() {
    this.props.submitFilters();
  }

  handleReset() {
    this.props.resetControls();
  }

  handleClear() {
    this.props.clearControls();
  }

  renderControls() {
    return this.props.controls.map((control, index) => {
      return (
        <EuiFlexItem
          key={control.id}
          style={{ minWidth: '250px' }}
          data-test-subj="inputControlItem"
        >
          <DateControl
            id={control.id}
            label={control.label}
            selected={moment()}
            disableMsg={control.isEnabled() ? null : control.disabledReason}
            controlIndex={index}
            startDate={control.value ? control.value.min : null}
            endDate={control.value ? control.value.max : null}
            stageFilter={this.props.stageFilter}
            clearControls={this.handleClear}
            showTimeSelect={this.props.showTimeSelect}
            dateFormat={this.props.dateFormat}
          />
        </EuiFlexItem>
      );
    });
  }

  render() {
    return (
      <div className="inputControlVis">
        <EuiFlexGroup wrap>
          {this.renderControls()}
        </EuiFlexGroup>
      </div>
    );
  }
}

InputControlVis.propTypes = {
  stageFilter: PropTypes.func.isRequired,
  showTimeSelect: PropTypes.bool.isRequired,
  dateFormat: PropTypes.string.isRequired,
  submitFilters: PropTypes.func.isRequired,
  resetControls: PropTypes.func.isRequired,
  clearControls: PropTypes.func.isRequired,
  controls: PropTypes.array.isRequired,
  hasChanges: PropTypes.func.isRequired,
  hasValues: PropTypes.func.isRequired,
  refreshControl: PropTypes.func.isRequired,
};
