import { dateControlFactory } from './date_control_factory';

export function controlFactory(controlParams) {
  let factory = null;
  switch (controlParams.type) {
    case 'date':
      factory = dateControlFactory;
      break;
    default:
      throw new Error(`Unhandled control type ${controlParams.type}`);
  }
  return factory;
}
