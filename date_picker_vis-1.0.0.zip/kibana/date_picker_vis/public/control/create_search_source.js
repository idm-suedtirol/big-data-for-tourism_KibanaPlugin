export function createSearchSource(kbnApi, initialState, indexPattern, aggs, useTimeFilter, filters = []) {
  const searchSource = new kbnApi.SearchSource(initialState);
  // Do not not inherit from rootSearchSource to avoid picking up time and globals
  searchSource.setParent(false);
  searchSource.setField('filter', () => {
    const activeFilters = [...filters];
    if (useTimeFilter) {
      activeFilters.push(kbnApi.timeFilter.createFilter(indexPattern));
    }
    return activeFilters;
  });
  searchSource.setField('size', 0);
  searchSource.setField('index', indexPattern);
  searchSource.setField('aggs', aggs);
  return searchSource;
}
