import './vis.less';
import { CATEGORY } from 'ui/vis/vis_category';
import { VisFactoryProvider } from 'ui/vis/vis_factory';
import { VisTypesRegistryProvider } from 'ui/registry/vis_types';
import { VisController } from './vis_controller';
import { ControlsTab } from './components/editor/controls_tab';
import { OptionsTab } from './components/editor/options_tab';
import { defaultFeedbackMessage } from 'ui/vis/default_feedback_message';
import image from './images/icon-input-control.svg';
import { Status } from 'ui/vis/update_status';
import { newControl } from './editor_utils';

function DatePickerVisProvider(Private) {
  const VisFactory = Private(VisFactoryProvider);

  // return the visType object, which kibana will use to display and configure new Vis object of this type.
  return VisFactory.createBaseVisualization({
    name: 'date_picker_vis',
    title: 'Date Picker',
    image,
    description: 'Create a date picker visualization on custom date field',
    category: CATEGORY.OTHER,
    requiresUpdateStatus: [Status.PARAMS, Status.TIME],
    feedbackMessage: defaultFeedbackMessage,
    visualization: VisController,
    visConfig: {
      defaults: {
        controls: [newControl('date')],
        useTimeFilter: false,
        showTimeSelect: false,
        dateFormat: "DD/MM/YYYY",
        timeFormat: "HH:mm",
      },
    },
    editor: 'default',
    editorConfig: {
      optionTabs: [
        {
          name: 'controls',
          title: 'Controls',
          editor: ControlsTab
        },
        {
          name: 'options',
          title: 'Options',
          editor: OptionsTab
        }
      ]
    },
    requestHandler: 'none',
    responseHandler: 'none',
  });
}

// register the provider with the visTypes registry
VisTypesRegistryProvider.register(DatePickerVisProvider);

// export the provider so that the visType can be required with Private()
export default DatePickerVisProvider;
