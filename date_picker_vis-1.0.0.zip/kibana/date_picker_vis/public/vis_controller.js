import React from 'react';
import { render, unmountComponentAtNode } from 'react-dom';
import { InputControlVis } from './components/vis/input_control_vis';
import { controlFactory } from './control/control_factory';
import { getLineageMap } from './lineage';

class VisController {
  constructor(el, vis) {
    this.el = el;
    this.vis = vis;
    this.controls = [];

    this.queryBarUpdateHandler = this.updateControlsFromKbn.bind(this);
    this.vis.API.queryFilter.on('update', this.queryBarUpdateHandler);
  }

  async render(visData, status) {
    if (status.params || (this.vis.params.useTimeFilter && status.time)) {
      this.controls = [];
      this.controls = await this.initControls();
      this.drawVis();
      return;
    }
    return;
  }

  destroy() {
    this.vis.API.queryFilter.off('update', this.queryBarUpdateHandler);
    unmountComponentAtNode(this.el);
  }

  drawVis = () => {
    render(
      <InputControlVis
        controls={this.controls}
        showTimeSelect={this.vis.params.showTimeSelect}
        dateFormat={this.vis.params.dateFormat}
        stageFilter={this.stageFilter}
        submitFilters={this.submitFilters}
        resetControls={this.updateControlsFromKbn}
        clearControls={this.clearControls}
        hasChanges={this.hasChanges}
        hasValues={this.hasValues}
        refreshControl={this.refreshControl}
      />,
      this.el);
  }

  async initControls() {
    const controlParamsList = this.vis.params.controls.filter((controlParams) => {
      // ignore controls that do not have indexPattern or field
      return controlParams.indexPattern && controlParams.fieldName;
    });

    const controlFactoryPromises = controlParamsList.map((controlParams) => {
      const factory = controlFactory(controlParams);
      return factory(controlParams, this.vis.API, this.vis.params.useTimeFilter);
    });
    const controls = await Promise.all(controlFactoryPromises);

    const getControl = (id) => {
      return controls.find(control => {
        return id === control.id;
      });
    };

    const controlInitPromises = [];
    getLineageMap(controlParamsList).forEach((lineage, controlId) => {
      // first lineage item is the control. remove it
      lineage.shift();
      const ancestors = [];
      lineage.forEach(ancestorId => {
        ancestors.push(getControl(ancestorId));
      });
      const control = getControl(controlId);
      control.setAncestors(ancestors);
      controlInitPromises.push(control.fetch());
    });

    await Promise.all(controlInitPromises);
    return controls;
  }

  stageFilter = async (controlIndex, newDates) => {
    this.controls[controlIndex].set(newDates);
    this.submitFilters();
  }

  submitFilters = () => {
    const stagedControls = this.controls.filter((control) => {
      return control.hasChanged();
    });

    const newFilters = stagedControls
      .filter((control) => {
        return control.hasKbnFilter();
      })
      .map((control) => {
        return control.getKbnFilter();
      });

    stagedControls.forEach((control) => {
      // to avoid duplicate filters, remove any old filters for control
      control.filterManager.findFilters().forEach((existingFilter) => {
        this.vis.API.queryFilter.removeFilter(existingFilter);
      });
    });

    this.vis.API.queryFilter.addFilters(newFilters);
  }

  clearControls = () => {
    this.controls.forEach((control) => {
      control.clear();
    });
    this.drawVis();
  }

  updateControlsFromKbn = async () => {
    this.controls.forEach((control) => {
      control.reset();
    });
    await this.updateNestedControls();
    this.drawVis();
  }

  async updateNestedControls() {
    const fetchPromises = this.controls.map(async (control) => {
      if (control.hasAncestors()) {
        await control.fetch();
      }
    });
    return await Promise.all(fetchPromises);
  }

  hasChanges = () => {
    return this.controls.map((control) => {
      return control.hasChanged();
    })
      .reduce((a, b) => {
        return a || b;
      });
  }

  hasValues = () => {
    return this.controls.map((control) => {
      return control.hasValue();
    })
      .reduce((a, b) => {
        return a || b;
      });
  }

  refreshControl = async (controlIndex, query) => {
    await this.controls[controlIndex].fetch(query);
    this.drawVis();
  }
}

export { VisController };
